import time, enum
from datetime import datetime

# Try importing the real hardware libraries; if they don't exist, provide no-op stubs.
try:
    from gpiozero import Button, PWMLED
except ImportError:
    class Button:
        def __init__(self, pin): pass
        def when_pressed(self, fn): pass

    class PWMLED:
        def __init__(self, pin):   self.value = 0
        def pulse(self):            pass

try:
    from smbus2 import SMBus
except ImportError:
    class SMBus:
        def __init__(self, bus): pass
        # you can add read/write stubs if you like

try:
    import serial
except ImportError:
    class Serial:
        def __init__(self, port, baud, timeout): pass
        def write(self, data): pass
    serial = type("serial", (), {"Serial": Serial})


# State machine definition
class ThermostatState(enum.Enum):
    OFF = 0
    HEATING = 1
    COOLING = 2

# GPIO pin definitions (unused by stubs)
BTN_MODE = 17
BTN_UP   = 27
BTN_DOWN = 22

LED_HEAT = PWMLED(23)
LED_COOL = PWMLED(24)

# I2C and sensor setup
I2C_BUS       = 1
AHT20_I2C_ADDR = 0x38

# UART setup (simulate server)
UART_PORT = '/dev/ttyUSB0'  # on Windows maybe 'COM3'
UART_BAUD = 9600

class Thermostat:
    def __init__(self):
        self.state     = ThermostatState.OFF
        self.set_point = 72.0

        self.bus  = SMBus(I2C_BUS)
        self.uart = serial.Serial(UART_PORT, UART_BAUD, timeout=1)

        # these calls will bind even to our stubs, so code can run
        Button(BTN_MODE).when_pressed(self.toggle_mode)
        Button(BTN_UP).when_pressed(self.increment_setpoint)
        Button(BTN_DOWN).when_pressed(self.decrement_setpoint)

    def toggle_mode(self):
        nxt = (self.state.value + 1) % len(ThermostatState)
        self.state = ThermostatState(nxt)

    def increment_setpoint(self):
        self.set_point += 1

    def decrement_setpoint(self):
        self.set_point -= 1

    def read_temperature(self):
        # placeholder: pretend the sensor drifts between 72°F and 73°F
        return 72.0 + (time.time() % 10) / 10

    def update_leds(self, temp_f):
        if self.state == ThermostatState.HEATING:
            if temp_f < self.set_point:
                LED_HEAT.pulse()
            else:
                LED_HEAT.value = 1
            LED_COOL.value = 0

        elif self.state == ThermostatState.COOLING:
            if temp_f > self.set_point:
                LED_COOL.pulse()
            else:
                LED_COOL.value = 1
            LED_HEAT.value = 0

        else:
            LED_HEAT.value = 0
            LED_COOL.value = 0

    def send_uart_update(self, temp_f):
        msg = f"{self.state.name},{temp_f:.2f},{self.set_point:.2f}\n"
        self.uart.write(msg.encode())

    def display_status(self, temp_f):
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"{now} | Temp: {temp_f:.2f}°F | Mode: {self.state.name} @ {self.set_point:.0f}°F")

    def run(self):
        try:
            while True:
                temp_c = self.read_temperature()
                temp_f = temp_c * 9/5 + 32
                self.update_leds(temp_f)
                self.display_status(temp_f)
                self.send_uart_update(temp_f)
                time.sleep(5)   # shorten for local testing
        except KeyboardInterrupt:
            print("Stopping thermostat.")

if __name__ == "__main__":
    Thermostat().run()
